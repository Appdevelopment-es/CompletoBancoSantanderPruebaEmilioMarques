//
//  FirebaseMessaging.h
//  FirebaseMessaging
//
//  Created by Emili Marques on 14/2/23.
//

#import <Foundation/Foundation.h>

//! Project version number for FirebaseMessaging.
FOUNDATION_EXPORT double FirebaseMessagingVersionNumber;

//! Project version string for FirebaseMessaging.
FOUNDATION_EXPORT const unsigned char FirebaseMessagingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FirebaseMessaging/PublicHeader.h>


