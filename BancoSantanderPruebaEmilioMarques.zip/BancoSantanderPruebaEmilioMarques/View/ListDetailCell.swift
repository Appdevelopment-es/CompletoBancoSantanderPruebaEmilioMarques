//
//  ListDetailCell.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 14/2/23.
//

import SwiftUI

struct ListDetailCell: View {
    var datos: Datos
    
    var body: some View {
        HStack {
            
            
                Text("\(datos.id)").foregroundColor(Color.gray)
                .font(.system(size: 12))
                
                
            Spacer()
                Text("\(datos.date)").foregroundColor(Color.blue)
                .font(.system(size: 15))
                
            Spacer()
                Spacer()
                if (datos.amount != 0) {
                    Text("\(datos.amount)").foregroundColor(Color.red)
                        .font(.system(size: 13))
                    
                } else if (datos.amount != 0) {
                    Text("\(datos.amount)").foregroundColor(Color.gray)
                        .font(.system(size: 15))
                }
            Spacer()
                   
                if (datos.fee != 0) {
                    Text("\(datos.fee)").foregroundColor(Color.gray)
                        .font(.system(size: 15))
                    
                } else if (datos.fee != 0) {
                    Text("\(datos.fee)").foregroundColor(Color.red)
                        .font(.system(size: 15))
                }
            Spacer()
                Text("\(datos.description)")
                .foregroundColor(Color.black)
                .font(.system(size: 16))
           
            }
        
    }
}

struct ListDetailCell_Previews: PreviewProvider {
    static var previews: some View {
        ListDetailCell(datos:Datos(id: Int(), date: Date(), amount: Int(), fee: Int(), description: String()))
    }
}
