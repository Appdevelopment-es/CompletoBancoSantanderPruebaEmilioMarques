//
//  NavLogoView.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 12/2/23.
//

import Foundation
import SwiftUI
import Combine

struct NavLogoView: View {

    var transaction: Transaction
    
    var body: some View {
        
        VStack{
            Image("logo")
                .renderingMode(.original)
                .aspectRatio(contentMode: .fill)
                .frame(width: 220, height: 35)
                .clipped()
                .cornerRadius(10)
                .shadow(radius: 10)
        }
        
            ZStack {
               Spacer()
                
                  
                TargetsView(datos: Datos(id: Int(), date: Date(), amount: Int(), fee: Int(), description: String()))
                Spacer()
                TransferView(datos: Datos(id: Int(), date: Date(), amount: Int(), fee: Int(), description: String()))
                DashboardView()
            }
            
    }
}

struct NavLogoView_Previews: PreviewProvider {
    static var previews: some View {
        NavLogoView(transaction: Transaction())
    }
}
