//
//  NoaView.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 14/2/23.
//

import SwiftUI

struct NoaView: View {
    var body: some View {
        SwiftSpeech.Demos.Basic()
    }
}

struct NoaView_Previews: PreviewProvider {
    static var previews: some View {
        NoaView()
    }
}
