//
//  DetailView.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 14/2/23.
//

import SwiftUI

struct DetailView: View {
    var datos: Datos
    
    var body: some View {
        Group{
            Section{
                ListDetailCell(datos: datos)
            }
        }
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView(datos: Datos(id: Int(), date: Date(), amount: Int(), fee: Int(), description: String()))
    }
}
