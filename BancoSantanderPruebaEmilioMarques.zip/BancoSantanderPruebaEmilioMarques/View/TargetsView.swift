//
//  TargetsView.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 12/2/23.
//

import SwiftUI

struct TargetsView: View {
    var datos: Datos
    
    var body: some View {
        
        VStack{
            Text("CARD INFORMATION")
            ZStack{
               
                Image("cards")
                     .frame(width: 50, height: 50)
            
            }
            
            .padding(200)
            
            ZStack{
                ListDetailCell(datos: datos)
            }
        }.navigationTitle("CARD INFORMATION")
    
    }
}

struct TargetsView_Previews: PreviewProvider {
    static var previews: some View {
        TargetsView(datos: Datos(id: Int(), date: Date(), amount: Int(), fee: Int(), description: String()))
    }
}
