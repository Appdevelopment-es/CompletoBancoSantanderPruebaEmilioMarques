//
//  DashboardView.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 11/2/23.
//

import SwiftUI
import Combine
import SwiftUI

struct DashboardView: View {
    var body: some View {
        TabView {
            HomeView(datos: Datos(id: Int(), date: Date(), amount: Int(), fee: Int(), description: String()))
                .tabItem {
                    Image(systemName: "square.grid.2x2.fill")
                    Text("Home")
            } .tag(0)
            TargetsView(datos: Datos(id: Int(), date: Date(), amount: Int(), fee: Int(), description: String()))
                .tabItem {
                    Image(systemName: "creditcard.and.123")
                    Text("Cards")
                        .font(.headline)
            } .tag(1)
            TransferView(datos: Datos(id: Int(), date: Date(), amount: Int(), fee: Int(), description: String()))
                .tabItem {
                    Image(systemName: "square.and.arrow.up.on.square.fill")
                    Text("Trans & Folder")
            } .tag(2)
            OthersOptionsView()
                .tabItem {
                    Image(systemName: "link.circle.fill")
                    Text("Web")
            } .tag(3)
            NoaView()
                .tabItem {
                    Image( "Noa_Icon")
                    Text("Sara")
            } .tag(4)
      
        }
    }
}

struct DashboardView_Preview: PreviewProvider {
    static var previews: some View {
        DashboardView()
    }
}
