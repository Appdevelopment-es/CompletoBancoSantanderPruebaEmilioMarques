//
//  InfoAlertView.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Developer on 14/2/23.
//

import SwiftUI

struct InfoAlertView: View {
    
    
    @State private var showingAlert = false

       var body: some View {
           Button("Alert Info") {
               showingAlert = true
           }
           .alert(isPresented: $showingAlert) {
               Alert(title: Text("Alert message"), message: Text("Your have recived the notification the bank Santander , by your money  account"), dismissButton: .default(Text("Show Message!")))
           } 
       }
   }

struct InfoAlertView_Previews: PreviewProvider {
    static var previews: some View {
        InfoAlertView()
    }
}
