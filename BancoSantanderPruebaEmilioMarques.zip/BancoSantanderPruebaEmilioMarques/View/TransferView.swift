//
//  TransferView.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 12/2/23.
//

import SwiftUI
import UIKit
import Combine



struct TransferView: View {
    
    
    var datos: Datos
    
    @State var inputIBANText: String = ""
    
    @State var inputSubjetText: String = ""
    
    @State private var showingAlert = false
    
    @State private var showingAlertConfirmation = false

    
    @State private var isCircleRotating = true
    @State private var animateStart = false
    @State private var animateEnd = true
    
    @State var navigated = true
 
    
    var body: some View {
        
        VStack{
            
            Text("TRANSFERENCIE INFORMATION")
            
            Image("transfer").frame(width: 250, height: 250)
            
            
            Text("Please insert your IBAN for ready transfer money a other bank, for transfer money.").foregroundColor(Color.gray)
            
            List{
                TextField("INSERT YOUR IBAN", text: $inputIBANText)
                    .frame(height: 44)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                if !inputIBANText.isEmpty {
                    Text("New IABAN: " + inputIBANText)
                }
                
                TextField("INSERT YOUR SUBJET", text: $inputSubjetText)
                    .frame(height: 44)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                if !inputSubjetText.isEmpty {
                    Text("New SUBJET: " + inputSubjetText)
                }
            }
            VStack{
                
                HStack{
                    Button("Delete", role: .destructive, action: {
                        showingAlert = true
                    })
                    
                    .alert(isPresented: $showingAlert) {
                        Alert(title: Text("Alert message"), message: Text("Your have recived the delete the bank Santander , by your money transfer account"), dismissButton: .default(Text("!Info Delete!")))
                    }
                    Spacer()
                    
                    Button(action: {}){
                        Text("")
                            .modifier(CustomTextM(fontName: "NunitoSans-Bold", fontSize: 16, fontColor: Color.black))
        
                        NavigationLink("Next", destination: LoadingView(), isActive: $navigated)
                    }
                    
                    Spacer()
                   
                    
                    
                    
                        
                        
                        .navigationTitle("TRANSFERENCIE")
                    }
                }
            }
        }
   
}

struct TransferView_Previews: PreviewProvider {
    static var previews: some View {
        TransferView(datos: Datos(id: Int(), date: Date(), amount: Int(), fee: Int(), description: String()))
    }
}
