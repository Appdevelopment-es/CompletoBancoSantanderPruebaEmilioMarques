//
//  OthersOptionsView.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 12/2/23.
//

import SwiftUI

struct OthersOptionsView: View {
    
    @State private var showingAlert = false
    
    var body: some View {
        VStack{
            
            Spacer()
            
            Link("Web Banck Santander", destination: URL(string: "https://www.bancosantander.es/particulares")!)
            
            Spacer()
            
            ZStack{
                Image("Banco_Santander")
                    .resizable()
                    .renderingMode(.original)
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 300, height: 300)
                    .clipped()
            }
            
            Spacer()
            
            Button("Alert Info") {
                showingAlert = true
            }
            .alert(isPresented: $showingAlert) {
                Alert(title: Text("Alert message"), message: Text("Your have recived the notification the bank Santander , by your money  account"), dismissButton: .default(Text("Show Message!")))
            } 
            Spacer()
            
        }.navigationTitle("Other Options")
            
    }
}

struct OthersOptionsView_Previews: PreviewProvider {
    static var previews: some View {
        OthersOptionsView()
    }
}
