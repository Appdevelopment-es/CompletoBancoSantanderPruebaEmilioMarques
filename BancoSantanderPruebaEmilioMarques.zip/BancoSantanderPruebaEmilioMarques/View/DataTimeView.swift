//
//  DataTimeView.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Developer on 19/2/23.
//

import SwiftUI

struct DataTimeView: View {
    
    @State var currentDate: Date = Date()
    
    var body: some View {
        
        VStack{
            
            Text("TRANSFER DATE & TIME INFORMATION")
            Spacer()
            
            Text("Please insert your date and Time for ready transfer money a other bank").foregroundColor(Color.blue)
            Spacer()
            DatePicker("Select Date", selection: $currentDate)
            Spacer()
            
            Button("Next", action: {
                
            })
        }
        .navigationTitle("DATA & TIME")
       
    }
}

struct DataTimeView_Previews: PreviewProvider {
    static var previews: some View {
        DataTimeView()
    }
}
