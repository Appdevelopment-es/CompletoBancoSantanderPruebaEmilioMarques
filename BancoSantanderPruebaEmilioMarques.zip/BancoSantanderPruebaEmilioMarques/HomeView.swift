//
//  HomeView.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 12/2/23.
//

import SwiftUI
import Combine
import CoreData
import Network
import CFNetwork




struct HomeView: View {
    @State var getLoadDatos: [Datos] = []
    
    @State private var showingAlert = false
    
    @State var datos: Datos
    
    @State var datajon = [Datos]()
    
    var body: some View {
        
        ZStack{
            
            NavigationView {
                NavigationLink(destination: DetailView(datos: Datos(id: Int(), date: Date(), amount: Int(), fee: Int(), description: String()))
                               
                ){
                    
                    
                    List{
                        
                        VStack(alignment: .leading) {
                            Section{
                                ListDetailCell(datos: datos)
                            }
                            
                        }
                        
                        
                        .onAppear{
                            apiCall().getLoadDatos {(datos ) in
                                self.getLoadDatos = datos
                            }
                        }
                        
                        
                    }
                    
                    .padding()
                    
                    .navigationBarTitle("BANCO SANTANDER")
                }
                
                .safeAreaInset(edge: .bottom, alignment: .trailing) {
                    Button {
                        NoaView()
                        
                    } label: {
                        Image(systemName: "info.circle.fill")
                            .font(.largeTitle)
                            .symbolRenderingMode(.monochrome)
                            .padding(.trailing)
                    }
                    .accessibilityLabel("Sara")
                }
                
            }
        }
    }

}




struct HomeView_Preview: PreviewProvider {
    static var previews: some View {
       
        HomeView(datos: Datos(id: Int(), date: Date(), amount: Int(), fee: Int(), description: String()))
    }
}
