//
//  LoadData.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 12/2/23.
//

import Foundation


class apiCall {

func getLoadDatos(completition: @escaping([Datos]) -> ()){
    guard let url = URL(string: "https://travel.webcindario.com/urlDatos.json") else { return }
        
    URLSession.shared.dataTask(with: url) { (data, _, _) in
        do {
            let datos = try JSONDecoder().decode([Datos].self, from: data!)
            
            DispatchQueue.main.async {
                completition(datos)
            }
            
        } catch {
            print(error.localizedDescription)
        }
    }
        .resume()
    }
}
