//
//  Datos.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 12/2/23.
//

import SwiftUI

struct Datos: Hashable, Codable, Identifiable {
    var id: Int
    var date: Date
    var amount: Int
    var fee: Int
    var description: String
    
    enum Catagory: String, CaseIterable, Codable, Hashable {
        case id = "ID"
        case date = "Date"
        case amount = "Amount"
        case fee = "Fee"
        case description = "Description"
    }
}
