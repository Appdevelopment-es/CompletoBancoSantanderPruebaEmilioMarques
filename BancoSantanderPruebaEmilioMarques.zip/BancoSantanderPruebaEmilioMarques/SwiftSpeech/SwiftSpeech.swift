//  SwiftSpeech.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 14/2/23.
//

import SwiftUI

public struct SwiftSpeech {
    public struct ViewModifiers { }
    public struct Demos { }
    internal struct EnvironmentKeys { }
    
    public static var defaultAnimation: Animation = .interactiveSpring()
}
