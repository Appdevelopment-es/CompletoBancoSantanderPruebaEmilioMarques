//
//  File.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 14/2/23.
//

import SwiftUI

@available(iOS 14.0, *)
struct LibraryContent: LibraryContentProvider {
    @LibraryContentBuilder
    var views: [LibraryItem] {
        LibraryItem(
            SwiftSpeech.RecordButton(),
            title: "Record Button"
        )
        
        LibraryItem(
            SwiftSpeech.Demos.Basic(locale: .current),
            title: "NoaTalkInfo - Basic"
        )
        
        LibraryItem(
            SwiftSpeech.Demos.Colors(),
            title: "NoaTalkInfo - Colors"
        )
        
        LibraryItem(
            SwiftSpeech.Demos.List(locale: .current),
            title: "NoaTalkInfo - NoaView"
        )
    }
    
    @LibraryContentBuilder
    func modifiers(base: AnyView) -> [LibraryItem] {
        LibraryItem(
            base.onAppear {
                SwiftSpeech.requestSpeechRecognitionAuthorization()
            },
            title: "Request Speech Recognition Authorization on Appear"
        )
    }
}
