//
//  Package.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 14/2/23.
//

import Foundation

final class Package {
    
    let package = Package.self
}
