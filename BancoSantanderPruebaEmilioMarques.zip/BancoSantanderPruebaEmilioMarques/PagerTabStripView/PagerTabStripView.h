//
//  PagerTabStripView.h
//  PuebaBancoSantander
//
//  Created by Emili Marques on 11/2/23.
//

#import <UIKit/UIKit.h>

//! Project version number for PagerTabStripView.
FOUNDATION_EXPORT double PagerTabStripViewVersionNumber;

//! Project version string for PagerTabStripView.
FOUNDATION_EXPORT const unsigned char PagerTabStripViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PagerTabStripView/PublicHeader.h>


