//
//  LoadingView.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 20/2/23.
//

import SwiftUI

struct LoadingView: View {
    
    @State private var isCircleRotating = true
    @State private var animateStart = false
    @State private var animateEnd = true
    
    @State var navigated = true
    
    var body: some View {
        VStack(spacing: 10){
            
            Circle()
                .trim(from: animateStart ? 1/3 : 1/9, to: animateEnd ? 2/5 : 1)
                .stroke(lineWidth: 10)
                .rotationEffect(.degrees(isCircleRotating ? 360 : 0))
                .frame(width: 100, height: 100)
                .foregroundColor(Color.gray)
                .onAppear() {
                    withAnimation(Animation
                        .linear(duration: 1)
                        .repeatForever(autoreverses: false)) {
                            self.isCircleRotating.toggle()
                        }
                    withAnimation(Animation
                        .linear(duration: 1)
                        .delay(0.5)
                        .repeatForever(autoreverses: true)) {
                            self.animateStart.toggle()
                        }
                    withAnimation(Animation
                        .linear(duration: 1)
                        .delay(1)
                        .repeatForever(autoreverses: true)) {
                            self.animateEnd.toggle()
                        }
                
            }
     
            
        }
        
        VStack(spacing: 20){
            Button(action: {}){
                Text("")
                    .modifier(CustomTextM(fontName: "NunitoSans-Bold", fontSize: 16, fontColor: Color.black))

                NavigationLink("Please waitting.Loading Access...", destination: DataTimeView(), isActive: $navigated)
            }
            
        }
    }
}

struct LoadingView_Previews: PreviewProvider {
    static var previews: some View {
        LoadingView()
    }
}
