//
//  Array+Extensions.swift
//  PuebaBancoSantander
//
//  Created by Emili Marques on 11/2/23.
//

import Foundation

extension Collection {
    subscript (safe index: Index) -> Element? {
        guard index >= startIndex, index < endIndex else { return nil }
        return self[index]
    }
}
