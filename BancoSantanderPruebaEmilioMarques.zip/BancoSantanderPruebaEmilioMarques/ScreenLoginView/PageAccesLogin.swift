//
//  PageAccesLogin.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 14/2/23.
//

import SwiftUI

struct PageAccesLogin: View {
    //MARK:- PROPERTIES
    @State private var username = ""
    @State private var password = ""
    
    
    @State var navigated = true
    
    var body: some View {
        VStack{
            
            // Welcome
            VStack(spacing:15){
                Text("Access your Account")
                    .modifier(CustomTextM(fontName: "RobotoSlab-Bold", fontSize: 34, fontColor: Color("red")))
                Text("Please sign in to continue.")
                    .modifier(CustomTextM(fontName: "RobotoSlab-Light", fontSize: 18, fontColor: Color.primary))
            }
            .padding(.top,45)
            Spacer()
            
            // Form
            VStack(spacing: 15){
                VStack(alignment: .center, spacing: 30){
                    VStack(alignment: .center) {
                        TextField("DNI O NIE.",
                                  text: $username)
                        Divider()
                            .background(Color.gray)
                    }
                    VStack(alignment: .center) {
                        TextField("Password",
                                   text: $password)
                        Divider()
                            .background(Color.gray)
                    }
                }
                HStack{
                    Spacer()
                    Button(action: {}){
                        Text("Forgot Pass?")
                            .modifier(CustomTextM(fontName: "RobotoSlab-Light", fontSize: 14, fontColor: Color.gray))
                    }
                }
            }
            .padding(.horizontal,35)
            
            //Button
            ZStack{
                NavigationLink("", destination: LoagingAccesAccount(), isActive: $navigated)
            }
          
            .padding(.top,35)
            Spacer()
            //SignUp
            Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/) {
                Text("Sign up, if you’re new!")
                    .modifier(CustomTextM(fontName: "RobotoSlab-Light", fontSize: 18, fontColor: Color.primary))
            }
            .padding(.bottom,30)
        }
    }
}

struct PageAccesLogin_Previews: PreviewProvider {
    static var previews: some View {
        PageAccesLogin()
    }
}

struct CustomTextM: ViewModifier {
    //MARK:- PROPERTIES
    let fontName: String
    let fontSize: CGFloat
    let fontColor: Color
    
    func body(content: Content) -> some View {
        content
            .font(.custom(fontName, size: fontSize))
            .foregroundColor(fontColor)
    }
}
