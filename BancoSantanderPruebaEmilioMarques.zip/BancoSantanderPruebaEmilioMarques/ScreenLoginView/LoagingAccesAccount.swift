//
//  ScreenTwo.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 14/2/23.
//

import SwiftUI

struct LoagingAccesAccount: View {
    //MARK:- PROPERTIES
    @State private var username = ""
    @State private var password = ""
    
    @State var navigated = true
    
    @State private var isCircleRotating = true
    @State private var animateStart = false
    @State private var animateEnd = true
    
    var body: some View {
        ZStack{
            
            //Bg
            Image("Banco_Santander")
                .resizable()
                .overlay(
                    Rectangle()
                        .foregroundColor(Color.black.opacity(0.65))
                )
                .ignoresSafeArea(.all)
            
            VStack{
              
               
                
                Spacer()
                // Form
                VStack(spacing: 15){
                    
                }
                .padding(.horizontal,35)
                
              
                Spacer()
                
                VStack(spacing: 15){
                    ZStack{
                        
                        NavigationLink("", destination: DashboardView(), isActive: $navigated)

                                Button(action: { self.navigated.toggle()
                                    
                                    
                                    Circle()
                                        .trim(from: animateStart ? 1/3 : 1/9, to: animateEnd ? 2/5 : 1)
                                        .stroke(lineWidth: 10)
                                        .rotationEffect(.degrees(isCircleRotating ? 360 : 0))
                                        .frame(width: 25, height: 25)
                                        .foregroundColor(Color.gray)
                                        .onAppear() {
                                            withAnimation(Animation
                                                .linear(duration: 1)
                                                .repeatForever(autoreverses: false)) {
                                                    self.isCircleRotating.toggle()
                                                }
                                            withAnimation(Animation
                                                .linear(duration: 1)
                                                .delay(0.5)
                                                .repeatForever(autoreverses: true)) {
                                                    self.animateStart.toggle()
                                                }
                                            withAnimation(Animation
                                                .linear(duration: 1)
                                                .delay(1)
                                                .repeatForever(autoreverses: true)) {
                                                    self.animateEnd.toggle()
                                                }
                                        }
                                        .frame(width: 60, height: 60)
                                    Image(systemName: "arrow.right")
                                        .font(.title)
                                        .foregroundColor(Color.white)
                                    
                                },
                                       label: {
                                    
                                    
                                }
                            )
                        
                        
                        
                                     

                    }
                   
                    
                }
                .padding(.horizontal,90)
                .padding(.bottom,30)
                
            }
            
        }
    }
}

struct LoagingAccesAccount_Previews: PreviewProvider {
    static var previews: some View {
        LoagingAccesAccount()
    }
}

struct ButtonStyle: ViewModifier {
    //MARK:- PROPERTIES
    let buttonHeight: CGFloat
    let buttonColor: Color
    let buttonRadius: CGFloat
    let CustomButton: CGFloat
    
    func body(content: Content) -> some View {
        content
            .frame(maxWidth: .infinity)
            .frame(height: buttonHeight)
            .background(buttonColor)
            .cornerRadius(buttonRadius)
    }
}
