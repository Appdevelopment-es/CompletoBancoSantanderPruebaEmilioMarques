//
//  ContentLoginView.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 14/2/23.
//

import SwiftUI

struct ContentLoginView: View {
    var body: some View {
        VStack{
            LoadingPageAcccessView()
        }
    }
}

struct ContentLoginView_Previews: PreviewProvider {
    static var previews: some View {
        ContentLoginView()
    }
}
