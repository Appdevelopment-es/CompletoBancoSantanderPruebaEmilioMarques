//
//  LoginAcces.swift
//  BancoSantanderPruebaEmilioMarques
//
//  Created by Emili Marques on 14/2/23.
//

import SwiftUI

struct LoginAcces: View {
    //MARK: - PROPERTIES
    @State var username: String = ""
    @State var password: String = ""
    
    @State var navigated = true
    
    
    var body: some View {
        ZStack{
            //  BG
            Image("Banco_Santander")
                .resizable()
                .edgesIgnoringSafeArea(.all)
            
            VStack{
                //  logo
                Image("logo")
                    .resizable()
                    .frame(width: 166.14, height: 26)
                    .padding(.top, 50)
                Spacer()
                //  Form
                VStack(spacing:0){
                    Label {
                        TextField("DNI O NIE.",
                                  text: $username)
          
                    } icon: {
                        Image(systemName: "person")
                            .frame(width: 14, height: 14)
                            .padding(.leading)
                    }.frame(height: 45)
                    .overlay(Rectangle().stroke(Color.white, lineWidth: 0.5).frame(height: 45))
                    
                    Label {
                        
                        TextField("Password",
                                  text: $password)
    
                    } icon: {
                        Image(systemName: "lock")
                            .frame(width: 14, height: 14)
                            .padding(.leading)
                    }.frame(height: 45)
                    .overlay(Rectangle().stroke(Color.white, lineWidth: 0.5).frame(height: 45))
                    
                }
                
                //  Button SignIn
                Button(action: {}){
                    Text("SIGN IN")
                        .modifier(CustomTextM(fontName: "NunitoSans-Bold", fontSize: 16, fontColor: Color.black))
    
                    NavigationLink("PageAccesLogin", destination: DashboardView(), isActive: $navigated)
                }
                .modifier(SFButton())
                .background(Color.white)
                .padding(.vertical,30)
                
                //  Forgot Password
                Text("Forgot Password")
                    .modifier(CustomTextM(fontName: "NunitoSans-Regular", fontSize: 16, fontColor: Color.white))
                    .padding(.bottom,30)
                    
            
            }.background(.red)
            .foregroundColor(.gray)
            .padding(.horizontal,20)
            
        }
    }
}

struct LoginAcces_Previews: PreviewProvider {
    static var previews: some View {
        LoginAcces()
    }
}

struct SFInputComponent: View {
    //    MARK:- PROPERTIES
    @State var inputTitle: String
    @Binding var username: String
    @State var isSecure: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8){
            Text(inputTitle)
                .modifier(CustomTextM(fontName: "MavenPro-Medium", fontSize: 16, fontColor: Color.gray))
            Group{
                if !isSecure {
                    TextField("", text: $username)
                } else {
                    SecureField("", text: $username)
                }
            }.padding(10)
            .font(Font.system(size: 15, weight: .medium, design: .serif))
            .foregroundColor(.primary)
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray, lineWidth: 0.5).frame(height: 45))
        }
    }
}

struct SFButton: ViewModifier {
    func body(content: Content) -> some View {
        content
            .frame(maxWidth: .infinity)
            .frame(height: 56, alignment: .leading)
    }
}
